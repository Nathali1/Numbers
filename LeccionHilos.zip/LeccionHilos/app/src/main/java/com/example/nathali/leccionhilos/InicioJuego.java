package com.example.nathali.leccionhilos;

import android.annotation.TargetApi;
import android.content.Context;
import android.os.AsyncTask;
import android.os.Build;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.TranslateAnimation;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

public class InicioJuego extends AppCompatActivity {

    TextView mostrarNombre2;

    RelativeLayout rl_footer,rl_footer2;
    TextView iv_header,iv_header2;
    boolean isBottom = true;
    Button btn1;

    ActualizarProgreso asyncTask1, asyncTask2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inicio_juego);

        mostrarNombre2 = (TextView)findViewById(R.id.lblnombre);

        mostrarNombre2.setText("Bienvenid@ "+getIntent().getExtras().getString("ParaNombre"));

        rl_footer = (RelativeLayout) findViewById(R.id.rl_footer);

        rl_footer = (RelativeLayout) findViewById(R.id.rl_footer2);

        iv_header = (TextView) findViewById(R.id.numuno);
        iv_header2 = (TextView) findViewById(R.id.numdos);

        Button button = (Button) findViewById(R.id.button1);
        Button buttonstop = (Button) findViewById(R.id.button2);
        buttonstop.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                rl_footer.clearAnimation();
                rl_footer.removeAllViews();
            }
        });

        button.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                //iv_header.setImageResource(R.drawable.delete);
                //iv_header.setPadding(0, 10, 0, 0);
                // rl_footer.setBackgroundResource(R.drawable.download);
                // if (isBottom) {

                long initialTime = System.currentTimeMillis();

                //SlideToDown();

                asyncTask1 = new ActualizarProgreso(InicioJuego.this,iv_header,rl_footer,initialTime);
                asyncTask1 = new ActualizarProgreso(InicioJuego.this,iv_header2,rl_footer2,initialTime);

                StartAsyncTaskInParallel(asyncTask1);
                StartAsyncTaskInParallel(asyncTask2);


            }
        });
    }

    @TargetApi(Build.VERSION_CODES.HONEYCOMB)
    private void StartAsyncTaskInParallel(ActualizarProgreso task) {
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB)
            task.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
        else
            task.execute();
    }

    public void SlideToDown() {
        Animation slide = null;
        slide = new TranslateAnimation(Animation.RELATIVE_TO_SELF, 0.0f,
                Animation.RELATIVE_TO_SELF, 0.0f, Animation.RELATIVE_TO_SELF,
                0.0f, Animation.RELATIVE_TO_SELF, 5.2f);

        slide.setDuration(400);
        slide.setFillAfter(true);
        slide.setFillEnabled(true);
        rl_footer.startAnimation(slide);

        slide.setAnimationListener(new Animation.AnimationListener() {

            @Override
            public void onAnimationStart(Animation animation) {

            }

            @Override
            public void onAnimationRepeat(Animation animation) {
            }

            @Override
            public void onAnimationEnd(Animation animation) {

//              rl_footer.clearAnimation();

                RelativeLayout.LayoutParams lp = new RelativeLayout.LayoutParams(
                        rl_footer.getWidth(), rl_footer.getHeight());
                lp.setMargins(0, rl_footer.getWidth(), 0, 0);
                lp.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM);
                rl_footer.setLayoutParams(lp);
                //iv_header.setImageResource(R.drawable.delete);
                //iv_header.setPadding(0, 10, 0, 0);
                //SlideToDown();
                //SlideToAbove();

            }

        });

    }


    public class ActualizarProgreso extends AsyncTask<Void,Integer,Boolean> {


        int result;

        Context ctx;

        TextView txtuno;
        RelativeLayout rl_footer;

        long timeStamp;



        public ActualizarProgreso(Context ctx, TextView txtuno, RelativeLayout rl_footer, long timeStamp){
            this.ctx = ctx;

            this.txtuno = txtuno;

            this.timeStamp = timeStamp;
            this.rl_footer=rl_footer;
        }

        protected void onPostExecute() {
            super.onPreExecute();

        }

        protected Boolean doInBackground(Void... arg0){

            for (int i = 0; i < 10; i++) {

                this.esperarXsegundos();

                SlideToDown();

                result = i;
                publishProgress(result);

            }

            return true;
        }

        private void esperarXsegundos() {
            try {
                Thread.sleep(2000);
            } catch (InterruptedException ex) {
                ex.printStackTrace();
            }
        }

        protected void onProgressUpdate(Integer... values){
            int num2;
            super.onProgressUpdate(values);

        }

        protected void onPostExecute(Boolean result){
            super.onPostExecute(result);
            long seg = (System.currentTimeMillis() - timeStamp) / 1000;

            txtuno.setText("-1");

        }

        protected void onCancelled(){
            Toast.makeText(ctx,"Tarea Cancelada", Toast.LENGTH_LONG).show();
        }


    }



}
