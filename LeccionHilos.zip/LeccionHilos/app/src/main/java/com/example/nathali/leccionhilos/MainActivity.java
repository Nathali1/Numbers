package com.example.nathali.leccionhilos;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {


    EditText enviarNombre;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        enviarNombre = (EditText)findViewById(R.id.infNombre);
    }

    public void iniciar(View w){

        Intent intent = new Intent(MainActivity.this,InicioJuego.class);
        intent.putExtra("ParaNombre",enviarNombre.getText().toString());
        startActivity(intent);
    }


}
